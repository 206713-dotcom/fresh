import React from "react";
import { SyllabusRevisionChecklist } from "./SyllabusRevisionChecklist";
import { DailyWeeklyChallenge } from "./DailyWeeklyChallenge";

interface SubjectSelectionStartPageProps {
  onSelectBusiness: () => void;
  onSelectEcons: () => void;
  onOpenBusinessGlossary: () => void;
  onSelectOfficialPastPapers?: () => void;
  onSelectPaper2?: () => void;
  onSelectEconsDiagrams?: () => void;
  onSelectEconsGlossary?: () => void;
  onSelectEconsBranch?: () => void;
  onSelectBusinessSection?: (sectionCode: string, topicCode?: string) => void;
  onSelectEconsSection?: (sectionCode: string, topicCode?: string) => void;
  onOpenFinanceExam?: () => void;
  onOpenStudySpace?: () => void;
  onOpenAvatarCustomizer?: () => void;
  onOpenAchievements?: () => void;
  theme: "light" | "dark";
  onToggleTheme: () => void;
}

export function SubjectSelectionStartPage({
  onSelectBusiness,
  onSelectEcons,
  onOpenBusinessGlossary,
  onSelectEconsGlossary,
  onSelectEconsDiagrams,
  onSelectBusinessSection,
  onSelectEconsSection,
  theme,
  onToggleTheme,
  onOpenStudySpace,
  onOpenAvatarCustomizer,
  onOpenAchievements,
}: SubjectSelectionStartPageProps) {
  return (
    <div className="min-h-screen bg-[#FAF9F6] dark:bg-black text-[#1C1917] dark:text-neutral-100 transition-colors flex flex-col justify-between">
      {/* Top Banner Navigation */}
      <header className="border-b border-[#E7E5E4] dark:border-neutral-800 px-4 sm:px-6 lg:px-8 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <span className="font-academic-serif text-xl sm:text-2xl font-bold tracking-tight text-[#0F2042] dark:text-white">
            EcBiz Study
          </span>
          <span className="text-xs font-mono text-[#78716C] dark:text-neutral-400 border-l border-[#D6D3D1] dark:border-neutral-700 pl-2.5 hidden sm:inline">
            CIE Cambridge Assessment Platform
          </span>
        </div>

        <div className="flex items-center gap-2">
          {onOpenAchievements && (
            <button
              onClick={onOpenAchievements}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-amber-500/40 bg-amber-500/10 hover:bg-amber-500/20 text-amber-700 dark:text-amber-300 text-xs font-semibold shadow-xs transition-all active:scale-95 cursor-pointer"
              title="View Achievements & Claim Bonus Coins"
            >
              <span>🏆</span>
              <span className="hidden sm:inline">Achievements</span>
            </button>
          )}

          {onOpenAvatarCustomizer && (
            <button
              onClick={onOpenAvatarCustomizer}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-indigo-500/30 bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-700 dark:text-indigo-300 text-xs font-semibold shadow-xs transition-all active:scale-95 cursor-pointer"
              title="Customise Scholar Avatar"
            >
              <span>🎨</span>
              <span className="hidden sm:inline">Avatar</span>
            </button>
          )}

          {onOpenStudySpace && (
            <button
              onClick={onOpenStudySpace}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white text-xs font-semibold shadow-xs transition-all active:scale-95 cursor-pointer"
              title="Open Aesthetic Study Space with Lo-Fi & Pomodoro"
            >
              <span>🎧</span>
              <span>Study Space</span>
            </button>
          )}

          <a
            href="https://forms.gle/6X2CAR1LkSQGRBx68"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#D6D3D1] dark:border-neutral-700 bg-white dark:bg-neutral-900 text-xs font-semibold text-[#0F2042] dark:text-neutral-200 hover:bg-[#F5F5F4] dark:hover:bg-neutral-800 transition-colors"
            title="Report a bug or suggest an improvement"
          >
            <span className="text-amber-600 dark:text-amber-400">💡</span>
            <span className="hidden sm:inline">Report Bug / Suggestion</span>
            <span className="sm:hidden">Feedback</span>
            <span className="text-[10px] opacity-70">↗</span>
          </a>

          <button
            onClick={onToggleTheme}
            aria-label="Toggle Dark Mode"
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-[#D6D3D1] dark:border-neutral-700 bg-white dark:bg-neutral-900 text-xs font-medium text-[#44403C] dark:text-neutral-200 hover:bg-[#F5F5F4] dark:hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            {theme === "dark" ? <span>☀ Light Theme</span> : <span>🌙 Dark Theme</span>}
          </button>
        </div>
      </header>

      {/* Main Start Screen Container */}
      <main className="max-w-5xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8 flex-1 flex flex-col justify-center">
        {/* Editorial Subheader */}
        <div className="text-center max-w-xl mx-auto mb-6">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-700 text-slate-700 dark:text-neutral-300 text-[11px] font-mono font-semibold uppercase tracking-wider mb-2">
            <span>●</span>
            <span>Cambridge International Examinations</span>
          </div>
          <h1 className="font-academic-serif text-2xl sm:text-3xl font-bold tracking-tight text-[#0F2042] dark:text-white leading-snug mb-1.5">
            Select Your Examination Subject
          </h1>
          <p className="text-xs sm:text-sm text-[#57534E] dark:text-neutral-400">
            Practice with authentic CIE Cambridge case studies, verified mark schemes, and strict rule-based assessment.
          </p>
        </div>

        {/* Two-Column Grid: Business Studies on the Left, Economics on the Right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
          {/* ========================================================= */}
          {/* LEFT COLUMN: BUSINESS STUDIES (FEATURING FEATURES + 2 BUTTONS) */}
          {/* ========================================================= */}
          <div className="lg:col-span-7 flex flex-col justify-between bg-white dark:bg-neutral-900 border-2 border-[#0F2042] dark:border-white rounded-xl p-5 sm:p-6 shadow-sm">
            <div>
              {/* Badge & Subject Header */}
              <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                <span className="px-2.5 py-0.5 rounded-full bg-[#0F2042] text-white dark:bg-white dark:text-black text-[11px] font-mono font-bold uppercase tracking-wider">
                  CIE Cambridge 0264 / 0450
                </span>
                <span className="text-[11px] font-mono font-semibold text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                  Active Syllabus Suite
                </span>
              </div>

              <h2 className="font-academic-serif text-xl sm:text-2xl font-bold text-[#0F2042] dark:text-white mb-1.5">
                Business Studies
              </h2>
              <p className="text-xs text-[#57534E] dark:text-neutral-400 leading-relaxed mb-4">
                Cambridge IGCSE / O Level Business Studies suite with 80 authentic case scenarios, 320 verified prompts, and instant Senior Examiner evaluation.
              </p>

              {/* Business Features List */}
              <div className="space-y-2 mb-5">
                <h3 className="text-[11px] font-mono font-bold uppercase tracking-wider text-[#0F2042] dark:text-neutral-200">
                  Key Business Features:
                </h3>
                <ul className="space-y-1.5 text-xs text-[#334155] dark:text-neutral-300">
                  <li className="flex items-start gap-2">
                    <span className="text-emerald-600 dark:text-emerald-400 font-bold shrink-0">✓</span>
                    <span><strong>80 Authentic Paper 1 Case Scenarios:</strong> Full case study stems across Sections 1, 2, 3 & 4.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-emerald-600 dark:text-emerald-400 font-bold shrink-0">✓</span>
                    <span><strong>320 Verified Exam Prompts:</strong> 2m, 4m, 6m, and 8m questions with full mark schemes.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-emerald-600 dark:text-emerald-400 font-bold shrink-0">✓</span>
                    <span><strong>Strict Assessment Rules:</strong> Automatic keyword scanning for AO2 and evaluative phrasing for AO4.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-emerald-600 dark:text-emerald-400 font-bold shrink-0">✓</span>
                    <span><strong>Local Senior Examiner AI (Qwen 0.5B):</strong> In-browser model confirms concept understanding (AO1) & analysis (AO3).</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-emerald-600 dark:text-emerald-400 font-bold shrink-0">✓</span>
                    <span><strong>0264 Syllabus Glossary & Definitions:</strong> Verified definitions with exam-tested advice.</span>
                  </li>
                </ul>
              </div>
            </div>

            {/* Straight Vertical Stack of 3 Flat Buttons: Enter Business -> Glossary -> Quizlet */}
            <div className="flex flex-col gap-2.5 pt-3.5 border-t border-[#E7E5E4] dark:border-neutral-800">
              {/* Button 1: Enter Business (Primary) */}
              <button
                type="button"
                onClick={onSelectBusiness}
                className="w-full py-2.5 px-5 rounded-lg bg-[#0F2042] dark:bg-white text-white dark:text-black font-academic-serif text-sm font-bold shadow-xs hover:bg-[#1E3A8A] dark:hover:bg-neutral-200 transition-all flex items-center justify-center gap-2 cursor-pointer group"
              >
                <span>Enter Business</span>
                <span className="group-hover:translate-x-1 transition-transform">→</span>
              </button>

              {/* Button 2: Glossary (Below Enter Business) */}
              <button
                type="button"
                onClick={onOpenBusinessGlossary}
                className="w-full py-2.5 px-5 rounded-lg bg-[#FAF9F6] dark:bg-black border border-slate-300 dark:border-neutral-700 text-[#0F2042] dark:text-white font-academic-serif text-xs font-semibold hover:border-[#0F2042] dark:hover:border-white transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>📖 0264 Syllabus Glossary & Definitions</span>
              </button>

              {/* Button 3: Quizlet Flashcards (Below Glossary) */}
              <a
                href="https://quizlet.com/user/Jayden_TAN53/folders/business-studies-0264"
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2.5 px-5 rounded-lg bg-[#FAF9F6] dark:bg-black border border-slate-300 dark:border-neutral-700 text-[#0F2042] dark:text-white font-academic-serif text-xs font-semibold hover:border-indigo-600 dark:hover:border-indigo-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-all flex items-center justify-center gap-2 cursor-pointer"
                title="Open Jayden_TAN53 official Quizlet Business Studies 0264 folder"
              >
                <span>🗂️ Quizlet 0264 Flashcards & Folder</span>
                <span className="text-[10px] opacity-70">↗</span>
              </a>
            </div>
          </div>

          {/* ========================================================= */}
          {/* RIGHT COLUMN: ECONOMICS                                    */}
          {/* ========================================================= */}
          <div className="lg:col-span-5 flex flex-col justify-between bg-white dark:bg-neutral-900 border border-[#E7E5E4] dark:border-neutral-800 rounded-xl p-5 sm:p-6">
            <div>
              <div className="flex items-center justify-between gap-2 mb-2">
                <span className="px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-neutral-800 text-slate-700 dark:text-neutral-300 text-[11px] font-mono font-bold uppercase tracking-wider">
                  CIE Cambridge 0455 / 2281
                </span>
                <span className="text-[11px] font-mono text-slate-500 dark:text-neutral-400">
                  Reference Only
                </span>
              </div>

              <h2 className="font-academic-serif text-xl sm:text-2xl font-bold text-[#0F2042] dark:text-white mb-1.5">
                Economics
              </h2>
              <p className="text-xs text-[#57534E] dark:text-neutral-400 leading-relaxed mb-4">
                CIE Cambridge 0455 Economics syllabus modules, diagrams, and past paper reference tools. Basic reference module kept lightweight and non-intrusive.
              </p>

              <div className="p-3.5 rounded-lg bg-[#FAF9F6] dark:bg-black border border-slate-200 dark:border-neutral-800 mb-4">
                <h4 className="text-[11px] font-mono font-bold text-slate-700 dark:text-neutral-300 uppercase tracking-wider mb-1.5">
                  Reference Syllabus Areas:
                </h4>
                <ul className="space-y-1 text-xs text-[#57534E] dark:text-neutral-400">
                  <li>• Section 1: Basic Economic Problem & PPC</li>
                  <li>• Section 2: Allocation of Resources & Price Mechanism</li>
                  <li>• Section 3: Microeconomic Decision Makers</li>
                  <li>• Section 4: Government and Macroeconomy</li>
                  <li>• Section 5: Economic Development & Living Standards</li>
                  <li>• Section 6: International Trade & Exchange Rates</li>
                </ul>
              </div>
            </div>

            {/* Straight Vertical Stack of 3 Flat Buttons for Economics */}
            <div className="flex flex-col gap-2.5 pt-3.5 border-t border-[#E7E5E4] dark:border-neutral-800">
              {/* Button 1: Enter Economics */}
              <button
                type="button"
                onClick={onSelectEcons}
                className="w-full py-2.5 px-5 rounded-lg bg-[#0F2042] dark:bg-white text-white dark:text-black font-academic-serif text-sm font-bold shadow-xs hover:bg-[#1E3A8A] dark:hover:bg-neutral-200 transition-all flex items-center justify-center gap-2 cursor-pointer group"
              >
                <span>Enter Economics</span>
                <span className="group-hover:translate-x-1 transition-transform">→</span>
              </button>

              {/* Button 2: Economics Glossary */}
              <button
                type="button"
                onClick={onSelectEconsGlossary || onSelectEcons}
                className="w-full py-2.5 px-5 rounded-lg bg-[#FAF9F6] dark:bg-black border border-slate-300 dark:border-neutral-700 text-[#0F2042] dark:text-white font-academic-serif text-xs font-semibold hover:border-[#0F2042] dark:hover:border-white transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>📖 0455 Economics Glossary & Formulas</span>
              </button>

              {/* Button 3: Interactive Diagrams */}
              <button
                type="button"
                onClick={onSelectEconsDiagrams || onSelectEcons}
                className="w-full py-2.5 px-5 rounded-lg bg-[#FAF9F6] dark:bg-black border border-slate-300 dark:border-neutral-700 text-[#0F2042] dark:text-white font-academic-serif text-xs font-semibold hover:border-[#0F2042] dark:hover:border-white transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>📈 Interactive Economic Curves & Blueprints</span>
              </button>
            </div>
          </div>
        </div>

        {/* ========================================================= */}
        {/* WORLDWIDE SYNCHRONIZED DAILY & WEEKLY 1-MINUTE CHALLENGE  */}
        {/* ========================================================= */}
        <div className="mt-8">
          <DailyWeeklyChallenge
            onOpenStudySpace={onOpenStudySpace}
            onNavigateToPractice={onSelectBusiness}
          />
        </div>

        {/* ========================================================= */}
        {/* INTERACTIVE SYLLABUS REVISION CHECKLIST (LOCAL STORAGE)   */}
        {/* ========================================================= */}
        <div className="mt-8">
          <SyllabusRevisionChecklist
            onSelectTopicForPractice={(subject, secCode, topCode) => {
              if (subject === "business" && onSelectBusinessSection) {
                onSelectBusinessSection(secCode, topCode);
              } else if (subject === "econs" && onSelectEconsSection) {
                onSelectEconsSection(secCode, topCode);
              } else {
                if (subject === "business") {
                  onSelectBusiness();
                } else {
                  onSelectEcons();
                }
              }
            }}
          />
        </div>

        {/* Footer attribution & Feedback Link */}
        <div className="mt-8 pt-4 border-t border-[#E7E5E4] dark:border-neutral-800 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-[#78716C] dark:text-neutral-500">
          <div>
            EcBiz Study · CIE Cambridge 0264 / 0450 Business Studies & 0455 Economics Practice Platform
          </div>
          <a
            href="https://forms.gle/6X2CAR1LkSQGRBx68"
            target="_blank"
            rel="noopener noreferrer"
            className="text-[#0F2042] dark:text-[#38BDF8] hover:underline font-semibold inline-flex items-center gap-1.5 transition-colors"
          >
            <span>💡 Report Bug or Suggest Improvement</span>
            <span>↗</span>
          </a>
        </div>
      </main>
    </div>
  );
}
